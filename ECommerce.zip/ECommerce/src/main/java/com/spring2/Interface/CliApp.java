package com.spring2.Interface;

import java.util.Scanner;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.spring2.Entity.Product;
import com.spring2.Services.CartService;
import com.spring2.Services.OrderService;
import com.spring2.Services.ProductService;

@Component
@Configuration
public class CliApp {
	@Autowired
	private ProductService productService;

	@Autowired
	private CartService cartService;

	@Autowired
	private OrderService orderService;

	public long a;
	public int b;

	Scanner scanner = new Scanner(System.in);

	@Bean
	public void run() {
		while (true) {
			System.out.println("Choose an option:");
			System.out.println("1. List all products");
			System.out.println("2. Add a product to the cart");
			System.out.println("3. View Cart");
			System.out.println("4. Place an order");
			System.out.println("5. View Order History");
			System.out.println("6. Exit");

			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				listAllProducts();
				break;
			case 2:
				addToCart();
				break;
			case 3:
				viewCart();
				break;
			case 4:
				placeOrder();
				break;
			case 5:
				OrderView();
				break;
			case 6:
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Input");
			}
		}
	}

	private void listAllProducts() {
		List<Product> products = productService.listAllProducts();
		products.forEach(System.out::println);
	}

	private void addToCart() {
		System.out.println("Please Enter the product ID of the product-  ");
		a = scanner.nextLong();
		Product product = new Product();
		if(a==product.getId()) {
			List<Product> products = productService.listAllProducts();
			products.forEach(System.out::println);
		cartService.addToCart(a,a);
		System.out.println("Product added to cart successfully");
		}
	}

	private void viewCart() {
		System.out.println("Products in the cart are -");
		b = scanner.nextInt();
		
		
		cartService.getProducts();

	}

	private void placeOrder() {
		System.out.println("Please enter the product Id of product you want to purchase");
		
	}

	private void OrderView() {
		System.out.println(orderService.viewOrderHistory());
	}

}
