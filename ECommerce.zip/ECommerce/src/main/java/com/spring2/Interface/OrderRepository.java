
package com.spring2.Interface;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring2.Entity.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {

	List<Order> findByOrderDateBetween(LocalDateTime startDate, LocalDateTime endDate);

	// Find orders by product name
	List<Order> findByProducts_Name(String productName);
}
