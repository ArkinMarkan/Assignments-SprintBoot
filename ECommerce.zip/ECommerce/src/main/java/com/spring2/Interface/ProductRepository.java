package com.spring2.Interface;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring2.Entity.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {
	
	   List<Product> findByName(String name);
	    
	    // Find products by price less than the specified value
	    List<Product> findByPriceLessThan(Double price);
	    
	    // Find products by stock greater than the specified value
	    List<Product> findByStockGreaterThan(Integer stock);
}
