package com.spring2.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring2.Entity.Cart;
import com.spring2.Entity.Product;
import com.spring2.Interface.CartRepository;

@Service
public class CartService {
	@Autowired
	private CartRepository cartRepository;

	@Autowired
	private ProductService productService;
	
	
	public void addToCart(Long cartId, Long productId) {
		Optional<Cart> optionalCart = cartRepository.findById(cartId);
		if (optionalCart.isPresent()) {
			Optional<Product> optionalProduct = productService.getProductById(productId);
			optionalProduct.ifPresent(product -> {
				Cart cart = optionalCart.get();
				cart.getProducts().add(product);
				cartRepository.save(cart);
		});
			}}
		
	
	/*public void addToCart(Long cartId, Long productId) {
		Optional<Cart> optionalCart = cartRepository.findById(cartId);
		if (optionalCart.isPresent()) {
			Optional<Product> optionalProduct = productService.getProductById(productId);
			optionalProduct.ifPresent(product -> {
				Cart cart = optionalCart.get();
				cart.getProducts().add(product);
				cartRepository.save(cart);
			});
		}
	} */

	/*public void viewCart(Long productId,Long cartId) {
		Optional<Cart> optionalCart = cartRepository.findById(cartId);
		if (optionalCart.isPresent()) {
			Cart cart = optionalCart.get();
			System.out.println("Products in Cart:");
			for (Product product : cart.getProducts()) {
				System.out.println(
						"ID: " + product.getId() + ", Name: " + product.getName() + ", Price: " + product.getPrice());
				break;
			}
		}
	}*/
	
	public void removeProductFromCart(Long cartId, Long productId) {
        Optional<Cart> optionalCart = cartRepository.findById(cartId);
        if (optionalCart.isPresent()) {
            Cart cart = optionalCart.get();
            cart.getProducts().removeIf(product -> product.getId().equals(productId));
            cartRepository.save(cart);
        }
    }
	
	public List<Cart> viewCart() {
		System.out.println("Products in Cart: ");
		return cartRepository.findAll();
	}
	
	public Cart getCartById(Long cartId) {
		return null;
	}


	public List<Cart> getProducts() {
		System.out.println("Products in Cart: ");
			return cartRepository.findAll();
		}
	}
