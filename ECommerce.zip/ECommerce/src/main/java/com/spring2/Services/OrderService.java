package com.spring2.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring2.Entity.Cart;
import com.spring2.Entity.Order;
import com.spring2.Interface.OrderRepository;

@Service
public class OrderService {

	@Autowired
	private OrderRepository orderRepository;
	
	@Autowired
	private CartService cartService;

	private List<Order> orderHistory;


	public String cartView(Cart cart) {
		return cart.toString();
	}

	public void placeOrder(Long cartId) {
		Cart cart = cartService.getCartById(cartId);
        if (!cart.getProducts().isEmpty() && cart != null) {
            Order order = new Order();
            order.setProducts(cart.getProducts());
            orderRepository.save(order);
	}}

	public List<Order> viewOrderHistory() {
		return orderRepository.findAll();
	}

}
