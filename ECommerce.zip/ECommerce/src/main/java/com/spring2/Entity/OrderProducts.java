package com.spring2.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name = "order_products")
public class OrderProducts {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long order_id;
	private Long products_id;

	public Long getOrder_id() {
		return order_id;
	}

	public void setOrder_id(Long order_id) {
		this.order_id = order_id;
	}

	public Long getProducts_id() {
		return products_id;
	}

	public void setProducts_id(Long products_id) {
		this.products_id = products_id;
	}

	public OrderProducts(Long order_id, Long products_id) {
		this.order_id = order_id;
		this.products_id = products_id;
	}

}
