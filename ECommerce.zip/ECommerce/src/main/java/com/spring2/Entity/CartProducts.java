package com.spring2.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name = "cart_products")
public class CartProducts {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long cart_id;
	private Long products_id;

	public Long getCart_id() {
		return cart_id;
	}

	public void setCart_id(Long cart_id) {
		this.cart_id = cart_id;
	}

	public Long getProducts_id() {
		return products_id;
	}

	public void setProducts_id(Long products_id) {
		this.products_id = products_id;
	}

	public CartProducts(Long cart_id, Long products_id) {
		this.cart_id = cart_id;
		this.products_id = products_id;
	}

}
