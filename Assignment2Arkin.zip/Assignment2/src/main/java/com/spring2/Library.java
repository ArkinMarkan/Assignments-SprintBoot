package com.spring2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;

public class Library {
	
	@Autowired
	private Book bk;
	
	public Library(Book bk) {
		this.bk = bk;
	}

	public void displayBookDetails() {
		System.out.println(bk.toString());
	}

}
