package com.spring2;

import org.springframework.beans.factory.annotation.Autowired;

public class Library {
	
	@Autowired
	private Book bk;
	
	public Library() {
		
	}
	
	public Library(Book bk) {
		this.bk = bk;
	}

	public void displayBookDetails() {
		System.out.println(bk.toString());
	}

	public Book getBk() {
		return bk;
	}

	public void setBk(Book bk) {
		this.bk = bk;
	}
	
}
