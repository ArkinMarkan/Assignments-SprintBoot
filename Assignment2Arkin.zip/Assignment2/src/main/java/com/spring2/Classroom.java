package com.spring2;

import org.springframework.beans.factory.annotation.Autowired;

public class Classroom {
	@Autowired
	private Student st;

	@Autowired
	public Classroom(Student st) {
		this.st = st;
	}

	public void displayStudentDetails() {
		System.out.println(st.toString());
	}
}
