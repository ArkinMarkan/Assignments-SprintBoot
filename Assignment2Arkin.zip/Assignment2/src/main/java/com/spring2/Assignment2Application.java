package com.spring2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Assignment2Application {

	public static void main(String[] args) {
		SpringApplication.run(Assignment2Application.class, args);
	}
	@Bean 
	public Book bk() {
		return new Book("This is demo","Arkin");
	}
	
	@Bean
	public Student st() {
		return new Student("Arkin",21);
	}
	
	@Bean
	public Library lb(Book bk) {
		return new Library(bk);
			}
	
	@Bean
	public Classroom cl(Student st) {
		return new Classroom(st);
	}
}
