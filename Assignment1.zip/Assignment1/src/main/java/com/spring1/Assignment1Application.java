package com.spring1;

import java.util.*;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.reactive.HttpHandlerAutoConfiguration.AnnotationConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring1.Entities.Student;
import com.spring1.service.studentService;

@SpringBootApplication
public class Assignment1Application {

	public static void main(String[] args) {
		SpringApplication.run(Assignment1Application.class, args);
		studentService student = new studentService();
			

		student.addStudent(new Student(1, "Arkin", 80));
		student.addStudent(new Student(2, "Paras", 50));
		
		
		// to get the data of all the students in the arraylist
		student.getAllStudents();
		//updating the scores for the students
		student.updateScore(1,70);
		student.updateScore(2,30);
		// fetching the values of the students by their id as input
		student.getStudentById(1);
		student.getStudentById(2);
		// calculating the scores of the student using the scores entered 
		student.calculateScores(1);
		// deleting the value by putting the index as 1
		student.deleteStudent(1);
		// Verifying the value has been deleted or not 
		student.getStudentById(1);
		
	
	}

}
